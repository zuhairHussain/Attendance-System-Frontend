import { Component } from '@angular/core';

@Component({
  selector: 'ngx-teacher',
  styleUrls: ['./teacher.component.scss'],
  templateUrl: './teacher.component.html',
})
export class TeacherComponent {
}
