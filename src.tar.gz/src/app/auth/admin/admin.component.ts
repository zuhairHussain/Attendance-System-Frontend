import { Component } from '@angular/core';

@Component({
  selector: 'ngx-admin',
  styleUrls: ['./admin.component.scss'],
  templateUrl: './admin.component.html',
})
export class AdminComponent {
}
