export class Location {
  constructor(public latitude: number = 53.9, public longitude: number = 27.5667) {
  }
}
